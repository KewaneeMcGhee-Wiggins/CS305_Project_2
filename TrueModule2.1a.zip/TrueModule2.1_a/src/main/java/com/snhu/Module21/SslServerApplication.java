package com.snhu.Module21;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

@RestController
class SslServerController{
	
	
	@GetMapping("/hash")
	public String myHash()throws NoSuchAlgorithmException{
		String data = "Hello";
		String name = "Kewanee McGhee";
		String [] splitname = name.split(" ");
		String firstname = splitname[0];
		String lastname = splitname[splitname.length - 1];
		name = firstname + " " + lastname;
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		byte[] sha256 = md.digest(name.getBytes(StandardCharsets.UTF_8));
		return "data: " + data + "</br><br>" + "Name: " + name + "</br><br>" + "Name of Cipher Algorithm Used: SHA-256" + bytesToHex(sha256);
		
	}
	public String bytesToHex(byte[] sha256) {
		BigInteger hex = new BigInteger(1, sha256);
		StringBuilder checksum = new StringBuilder(hex.toString(16));
		
		while(checksum.length() < 32) {
			checksum.insert(0, '0');
			
		}
		return checksum.toString();
	}
}